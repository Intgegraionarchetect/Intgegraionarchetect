import { SinglyLinkedList } from '../singly_linked_list'
import { testLinkedList } from './linked_list'

describe('Singly linked list', () => testLinkedList(SinglyLinkedList))
