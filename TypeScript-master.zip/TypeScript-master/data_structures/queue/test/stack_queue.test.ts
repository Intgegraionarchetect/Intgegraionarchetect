import { testQueue } from './queue'
import { StackQueue } from '../stack_queue'

describe('Stack Based Queue', () => testQueue(StackQueue))
